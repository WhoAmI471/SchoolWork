def shift_encode(string):
    if string.isalpha():
        number = ord(string) + 1 % 32
        return chr(number)
    return string

def shift_decode(encode):
    if encode.isalpha():
        number = ord(encode) - 1 % 32
        return chr(number)
    return encode

encode = ''
decode = ''

user_input = input()

for i in user_input:
    encode += shift_encode(i)
print(encode)

for j in encode:
    decode += shift_decode(j)
print(decode)
